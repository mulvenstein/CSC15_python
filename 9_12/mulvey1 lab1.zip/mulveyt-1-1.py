#File: mulvey-1.1.py
#Purpose: Displays my full name, full address, telephone number, and my degree/major
#Author: Thomas Mulvey
#Date: 9/12/2017
#Version: 1.01

def main():
	print("Thomas Mulvey")
	print("14 Hutchinson Rd, Merrimack NH, 03054")
	print("(603)-913-3952")
	print("Bachelor of Science in Computer Science")
	return
#---#
main()